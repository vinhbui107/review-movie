import axiosClient from "./axiosClient";
import { urlToken, urlRegister } from '../utils/constants';

const userApi = {
    login: (params) => {
        const username = params.username;
        const password = params.password;
        return axiosClient.post(urlToken, { username, password });
    },

    logout: () => {},

    register: (params) => {
        return axiosClient.post(urlRegister, { params });
    },

    getUser: () => {
        const url = "/auth";
        return axiosClient.get(url);
    },
};

export default userApi;
