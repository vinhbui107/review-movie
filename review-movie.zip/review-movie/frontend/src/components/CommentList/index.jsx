import React, { useState } from "react";
import Comments from "../Comment";

// import { Editor, handleChange } from "../../utils/constants";

function CommentList() {
    return (
        <div>
            <Comments />
        </div>
    );
}

export default CommentList;
