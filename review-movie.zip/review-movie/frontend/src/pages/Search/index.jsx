import React from "react";

function Search() {
  return (
    <div>
      <h2>Search</h2>
    </div>
  );
}

export default Search;
