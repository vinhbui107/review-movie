import React from "react";
import "./style.scss";

function NotFound() {
    return (
        <div className="not-found">
            <h2>NotFound</h2>
            <h2>NotFound</h2>
            <h2>NotFound</h2>
            <h2>NotFound</h2>
            <h2>NotFound</h2>
            <h2>NotFound</h2>
            <h2>NotFound</h2>
            <h2>NotFound</h2>
            <h2>NotFound</h2>
            <h2>NotFound</h2>
        </div>
    );
}

export default NotFound;
