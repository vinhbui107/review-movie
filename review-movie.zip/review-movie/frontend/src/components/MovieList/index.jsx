import React, { useState } from "react";
import { Row, Col } from "react-bootstrap";
import OwlCarousel from "react-owl-carousel";
import { Link } from "react-router-dom";
import MovieCard from "../MovieCard";
import style from "./style.module.scss";

function MovieList(props) {
    // const handleRender = () => {
    //     if (items !== 6) {
    //         pagination(12);
    //         return (
    //             <OwlCarousel
    //                 className={style["owl-theme"]}
    //                 loop
    //                 margin={10}
    //                 slideBy="12"
    //                 items="1"
    //                 lazyLoad="true"
    //                 smartSpeed="400"
    //                 nav="true"
    //             >
    //                 {content.map((item, index) => {
    //                     return <Row key={index}>{getDataMovie(item.first, item.last)}</Row>;
    //                 })}
    //             </OwlCarousel>
    //         );
    //     } else {
    //         pagination(6);
    //         return (
    //             <OwlCarousel
    //                 className={style["owl-theme"]}
    //                 loop
    //                 margin={10}
    //                 slideBy="12"
    //                 items="1"
    //                 lazyLoad="true"
    //                 smartSpeed="400"
    //                 nav="true"
    //             >
    //                 {content.map((item, index) => {
    //                     return <Row key={index}>{getDataMovie(item.first, item.last)}</Row>;
    //                 })}
    //             </OwlCarousel>
    //         );
    //     }
    // };

    return (
        <div></div>
        // <Row>
        //     <h1 className={style.title}>
        //         {logo ? <span className={style.title__logo}>{logo}</span> : ""}
        //         {title}
        //     </h1>
        //     {handleRender()}
        // </Row>
    );
}

export default MovieList;
