import React from "react";

function MovieGenre() {
    return (
        <div>
            <h2>MovieGenre</h2>
        </div>
    );
}

export default MovieGenre;
